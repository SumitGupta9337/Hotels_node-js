const mongoose = require("mongoose");
const MenuItem = require("./MenuItem");


const orderSchema = new mongoose.Schema({

    customer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "user",
        required: true
    },

    waiter:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "user"
    },

    table:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "table",
        required: true
    },

    items:[{

        menuItem:{
            type: mongoose.Schema.Types.ObjectId,
            ref: "menu",
            required: true
        },

        quantity:{
            type: Number,
            required: true,
            default: 1 
            
        },

        price:{
            type: Number,
            required: true
        },

    }],

    totalAmount:{
        type: Number,
        required: true
    },

    status:{
        type: String,
        enum:["pending" ,"preparing" ,"ready" , "served"],
        default: "pending",
    }


},
{
    timestamps: true,
  })

module.exports = mongoose.model("Order", orderSchema);