const {default: mongoose} = require('mongoose');

const tableSchema = new mongoose.Schema({

    tableNumber:{
        type: Number,
        required: true
    },

    capacity:{
        type: Number,
        required: true
    },

    status:{
        type: String,
        enum:['available' , 'occupied'],
        default: "available"

    }
})

const table = mongoose.model('table',tableSchema);
module.exports = table ; 