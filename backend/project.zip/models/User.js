const {default: mongoose} = require("mongoose")
const bcrypt = require('bcrypt') 

const userSchema = new mongoose.Schema({

    name:{
        type: String,
        required: true
    },

    email:{
        type: String,
        required: true

    },

    password:{
        type: String,
        required: true
    },

    role:{
        type: String,
        enum:['manager' , 'customer' , 'chef' , 'waiter' ],
        required: true
    }
})


// This middleware runs automatically BEFORE a Person document is saved
userSchema.pre('save', async function () {

    // 'this' refers to the current Person document being saved

    // If the password has not changed, do not hash it again
    if (!this.isModified('password')) {
        return;
    }

    // Generate a salt with 10 rounds
    const salt = await bcrypt.genSalt(10);

    // Hash the plain-text password using the generated salt
    const hashedPassword = await bcrypt.hash(this.password, salt);

    // Replace the plain-text password with the hashed password
    this.password = hashedPassword;
});

userSchema.methods.comparePassword = async function(candidatePassword){
    try {
        const isMatch = await bcrypt.compare(candidatePassword , this.password);
        return isMatch;
        
    } catch (error) {
        throw error;
        
    }
}


const user = mongoose.model('user' , userSchema);
module.exports = user;