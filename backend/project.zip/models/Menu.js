const {default: mongoose} = require("mongoose")

const menuSchema = new mongoose.Schema({

    name:{
        type: String,
        required: true
    },

    category:{
        type: String,
        enum:['veg' , 'non-veg'],
        required: true

    },

    price:{
        type: Number,
        required: true
    },

    available: {
        type: Boolean,
        default: true
    },

    description: {
        type: String
    }

})

const menu = mongoose.model('menu', menuSchema);
module.exports = menu;