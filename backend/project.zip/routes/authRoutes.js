const express = require('express');
const router = express.Router();
const user = require('./../models/user');
const {jwtAuthMiddleware , generateToken} = require('../middlewares/jwt')



router.post('/register' , async (req , res)=>{
    try {
        const data = req.body;

        const response = await user.create(data);
        console.log('data saved ');

        const payload = {
            id: response.id,
            email: response.email
        }

        console.log(JSON.stringify(payload));
        const token = generateToken(payload);
        console.log("Token is : ", token);
        res.status(200).json({response: response , token : token });


    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'})
    }
})


router.post('/login' , async (req, res)=>{
    try {
        const {email , password } = req.body;
        const foundUser = await user.findOne({email: email})

        if(!foundUser){
            return res.status(200).json({error: 'Invalid Email or Password'});
        }

        
        const isMatch = await foundUser.comparePassword(password);

        
        if(!isMatch){
            return res.status(200).json({error: 'Invalid Email or Password'});
        }

        //generate token 
        const payload = {
            id: foundUser.id,
            email: foundUser.email 
        }

        const token = generateToken(payload);

        res.json({token})

        

    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'})
    }
})


router.get('/profile', jwtAuthMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;

        const userFound = await user.findById(userId).select("-password");

        res.status(200).json(userFound);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

module.exports = router;