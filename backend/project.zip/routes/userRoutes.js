const express = require('express');
const router = express.Router();
const user = require('./../models/user');
const {jwtAuthMiddleware , generateToken} = require('./../jwt')


router.get('/', async (req,res)=>{
    try {

        const data = await user.find();
        console.log('data fetched');
        res.status(200).json(data)

        
    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})

router.get('/:id', async (req,res)=>{
    try {
    

        const data = await user.findById(req.params.id);

        if(!data)
        {
            res.status(401).json({error: "user not found"})
        }

        console.log('data fetched');
        res.status(200).json(data)

        
    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})


router.post('/',async (req, res)=>{
    try{
        const data = req.body
        const newuser = new user(data);

        const response = await newuser.save();
        console.log('data saved');
        res.status(200).json(response)


    }catch(err){
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});

    }
})

router.put('/:id',async (req,res)=>{
    try {
        const userId = req.params.id;
        const updateUserData= req.body;

        const response = await user.findByIdAndUpdate(userId , updateUserData,{
            new : true,
            runValidators: true
            
        });

        if(!userId)
        {
            res.status(401).json({error: "user not found"})
        }

        console.log('data updated sucessfully');
        res.status(200).json(response)


    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})

router.delete('/:id' , async (req, res)=>{
    try{
        const response = await user.findByIdAndDelete(req.params.id);

        if(!response)
        {
            res.status(404).json({error: "User id not found"})
        }

        console.log("user Deleted ")
        res.status(200).json(response)
    }catch(err){
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'})
    }
})



module.exports = router;