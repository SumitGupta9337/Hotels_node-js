const express = require('express');
const router = express.Router();
const user = require('../models/User');
const table = require('../models/Table');
const order = require('../models/Orders');
const MenuItem = require('../models/Menu');
const {jwtAuthMiddleware , generateToken} = require('../middlewares/jwt')

router.get('/', async (req,res)=>{
    try {

        const data = await order.find();
        console.log('data fetched');
        res.status(200).json(data)

        
    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})

router.get('/:id', async (req,res)=>{
    try {
    

        const data = await order.findById(req.params.id);

        if(!data)
        {
            res.status(401).json({error: "order not found"})
        }

        console.log('data fetched');
        res.status(200).json(data)

        
    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})

router.post('/', async (req, res) => {
    try {

        const { customer, waiter, table, items } = req.body;

        let orderItems = [];
        let totalAmount = 0;

        for (const item of items) {

            const menu = await MenuItem.findById(item.menuItem);

            if (!menu) {
                return res.status(404).json({
                    message: "Menu item not found"
                });
            }

            orderItems.push({
                menuItem: menu._id,
                quantity: item.quantity,
                price: menu.price
            });

            totalAmount += menu.price * item.quantity;
        }

        const newOrder = new order({
            customer,
            waiter,
            table,
            items: orderItems,
            totalAmount
        });

        const response = await newOrder.save();

        res.status(201).json(response);

    } catch (err) {
        console.log(err);
        res.status(500).json({
            error: "Internal Server Error"
        });
    }
});

router.put('/:id',async (req,res)=>{
    try {
        const orderId = req.params.id;
        const updateOrderData= req.body;

        const response = await order.findByIdAndUpdate(orderId , updateOrderData,{
            new : true,
            runValidators: true
            
        });

        if(!orderId)
        {
            res.status(401).json({error: "Order not found"})
        }

        console.log('Order data updated sucessfully');
        res.status(200).json(response)


    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})

router.delete('/:id' , async (req, res)=>{
    try{
        const response = await order.findByIdAndDelete(req.params.id);

        if(!response)
        {
            res.status(404).json({error: "order id not found"})
        }

        console.log("order Deleted ")
        res.status(200).json(response)
    }catch(err){
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'})
    }
})
module.exports = router;