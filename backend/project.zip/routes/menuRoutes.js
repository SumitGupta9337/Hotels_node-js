const express = require('express');
const router = express.Router();
const menu = require("../models/menu");
const {jwtAuthMiddleware , generateToken} = require('./../jwt')



router.get('/' , async (req,res) =>{
    try{
        const data = await menu.find();
        console.log('data fetched');
        res.status(200).json(data);

    }catch(err){
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})

router.get('/:id', async (req,res)=>{
    try {
    

        const data = await menu.findById(req.params.id);

        if(!data)
        {
            res.status(401).json({error: "Menu item not found"})
        }

        console.log('data fetched');
        res.status(200).json(data)

        
    } catch (err) {
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'});
    }
})

router.post('/' , async (req,res) => {
    try{
        const data = req.body
        const newItem = new menu(data);

        const response = await menu.insertMany(data);
        console.log('data saved');
        res.status(200).json(response);

    }catch(err){
        console.log(err);
        res.status(500).json({error: 'Internal Server Error'})

    }

})


router.put('/:id' , async (req,res) => {
    try{
        const menuId = req.params.id; // extract id from url parameter 
        const updateUserData = req.body; //extract updated data for the person

        const response = await user.findByIdAndUpdate(menuId , updateUserData,{
            new : true, //Return the updated document 
            runValidators: true, // Run mongoose Validation 
        })

        if(! response){
            return res.status(404).json({error: 'User not found'})
        }

        console.log('Data Updated');
        res.status(200).json(response)

    }catch(err){
        console.log(err);
        res.status(500).json({error: "Internal server error"})
    }
})


router.delete('/:id' , async (req , res) => {
    try {

        const menuId = req.params.id;
        const response = await user.findByIdAndDelete(menuId);

        if(! response){
            return res.status(404).json({error: 'Person not found'})
        }

        console.log('Data Deleted');
        res.status(200).json(response)

        
    } catch (err) {
        console.log(err);
        res.status(500).json({error: "Internal server error"})
        
    }
})

module.exports = router;